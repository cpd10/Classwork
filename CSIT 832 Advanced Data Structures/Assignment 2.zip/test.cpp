#include <iostream>
#include <fstream>
#include <conio.h>
#include "graph.h"
#include "queue.h"
using namespace std;
int menu();

int main()
{
	int choice;
	City flights[MAX];
	ifstream file;
	file.open("load.txt");
	for (int i = 0; i < MAX; i++)
	{
		file >> flights[i].name >> flights[i].weight[0] >> flights[i].weight[1] 
			>> flights[i].weight[2] >> flights[i].weight[3] >> flights[i].weight[4] 
			>> flights[i].weight[5] >> flights[i].weight[6];
		flights[i].position = i;
		flights[i].mark = false;
	}
	file.close();

	Graph airline(flights);
	do
	{
		switch (choice = menu())
		{
			case 1: int dep_city, des_city;
				cout << "\nDeparture Cities";
				cout << "\n=================\n";
				for (int i = 0; i < MAX; i++)
					cout << i + 1 << ". " << flights[i].name << endl;
				cout << "Choose city: ";
				cin >> dep_city;
				cout << "\nDestination Cities";
				cout << "\n===================\n";
				for (int j = 0; j < MAX; j++)
					if (flights[j].name != flights[dep_city - 1].name)
						cout << j + 1 << ". " << flights[j].name << endl;
				cout << "Choose city: ";
				cin >> des_city;
				airline.BreadthFirstSearch(flights[dep_city - 1], flights[des_city - 1]);
				cout << "\nPress any key to return to menu\n\n";
				_getch();
				break;
		}
	} while (choice != 2);
	return 0;
}

int menu()
{
	int sel;
	cout << "1. Choose departure city" << "\n2. Exit";
	cout << "\nSelection: ";
	cin >> sel;
	return sel;
}