//Darius Hooks
#include <iostream>
#include <iomanip>
#include "toll.h"
using namespace std;

int TollBooth::m_nCourseCount = 0;

int TollBooth::getCourseCount()
{
	return m_nCourseCount;
}

void TollBooth::setStudents()
{
	int entered;
	m_nCourseCount++;
	
	cout << "\nHow many students entered the room? ";
	cin >> entered;
	cout << "How many students paid? ";
	cin >> m_nPayingStu;
	while (m_nPayingStu > entered)
	{
		cout << "\n****Invalid input: more paying than entered!****";
		cout << "\nHow many students entered the room? ";
		cin >> entered;
		cout << "How many students paid? ";
		cin >> m_nPayingStu;
	}
	m_nDeadbeatStu = entered - m_nPayingStu;

}

void TollBooth::getStudents(float& toll)
{
	toll += float(m_nPayingStu * .50);
	cout << endl << m_nPayingStu + m_nDeadbeatStu << " students are in the course";
	cout << "\nThe toll collected is $" << fixed << setprecision(2) << float(m_nPayingStu * .50);
	if (m_nDeadbeatStu == 1)
		cout << endl << m_nDeadbeatStu << " student didn't pay\n";
	else if (m_nDeadbeatStu > 1)
		cout << endl << m_nDeadbeatStu << " students didn't pay\n";
	else if (m_nDeadbeatStu == 0)
		cout << "\nAll students paid\n";
}