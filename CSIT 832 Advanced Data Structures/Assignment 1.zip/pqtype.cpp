#include "pqtype.h"

PQType::PQType(int max)
{
	maxItems = max;
	items.elements = new HeapType[max];
	length = 0;
}

PQType::~PQType()
{
	delete [] items.elements;
}

void PQType::MakeEmpty()
{
	length = 0;
}

bool PQType::IsEmpty()
{
	if (length == 0)
		return true;
	return false;
}

bool PQType::IsFull()
{
	if (length == maxItems)
		return true;
	return false;
}

void PQType::Enqueue(Printer newItem)
{
		length++;
		items.elements[length - 1].numElements = newItem.job;
		items.elements[length - 1].priorityElements = newItem.priority;
		items.ReheapUp(0, length - 1);
}

void PQType::Dequeue(Printer& item)
{
	item.job = items.elements[0].numElements;
	item.priority = items.elements[0].priorityElements;
	items.elements[0] = items.elements[length - 1];
	length--;
	items.ReheapDown(0, length - 1);
}
