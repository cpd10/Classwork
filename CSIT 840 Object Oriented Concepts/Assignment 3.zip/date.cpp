//Darius Hooks
#include "date.h"
#include <iostream>
using namespace std;
int MAX[] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }; //Used to check for validity
Date::Date()
{
	month = 1;
	day = 1;
	year = 2001;
}

Date::Date(const Date &date1)
{
	month = date1.month;
	day = date1.day;
	year = date1.year;
}

bool Date::operator==(const Date& date2)
{
	if (month == date2.month) 
		if(day == date2.day) 
			if(year == date2.year)
				return true;
	return false;
}

bool Date::operator>(const Date& date)
{
	if (year > date.year)
		return true;
	
	else if (year == date.year)
	{
		if (month > date.month)
			return true;
		else if (month == date.month)
			if (day > date.day)
				return true;
		return false;
	}

	return false;
}

Date Date::operator-(const Date& date)
{
	Date tmp;
	
	tmp.day = day - date.day;
	if (day < date.day)
	{
		tmp.day = ((day + 30) - date.day);
		tmp.month = (month - 1) - date.month;
		if ((month - 1) < date.month)
		{
			tmp.month = (((month - 1) + 12) - date.month);
			tmp.year = (year - 1) - date.year;
			return tmp;
		}
		tmp.year = year - date.year;
		return tmp;
	}
	tmp.month = month - date.month;
	tmp.year = year - date.year;
	return tmp;
}

Date Date::operator=(const Date& date)
{
	month = date.month;
	day = date.day;
	year = date.year;
	return *this;
}

istream& operator>>(istream& strm, Date& date)
{
	cout << "\nEnter month(1 - 12): ";
	strm >> date.month;
	if (date.month > 12 || date.month < 1)
	{
		cout << "\nInvalid! Enter valid month: ";
		strm >> date.month;
	}
	
	cout << "\nEnter day(1 to max days in month): ";
	strm >> date.day;
	if (date.day > MAX[date.month])
	{
		cout << "\nInvalid! Enter valid day: ";
		strm >> date.day;
	}
	
	cout << "\nEnter year(>=1800): ";
	strm >> date.year;
	if (date.year < 1800)
	{
		cout << "\nInvalid! Enter valid year: ";
		strm >> date.year;
	}
	
	return strm;
}

ostream& operator<<(ostream& strm, Date& date)
{
	strm << date.month << "/" << date.day << "/" << date.year;
	return strm;
}