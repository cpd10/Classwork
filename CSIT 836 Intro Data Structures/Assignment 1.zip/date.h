#ifndef DATE_H
#define	DATE_H
class Date
{
	int month, day, year;
	public:
		void setDate(int, int, int);
		void printDate();
};
#endif
