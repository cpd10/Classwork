#include <iostream>
#include "cstack.h"
#include <conio.h>
using namespace std;
bool IsValidExpression(CStack&, char[]);
int main()
{
	char expression[21];
	cout << "Enter an expression: ";
	cin.getline(expression, 21, '\n');

	CStack stack1;
	
	if (IsValidExpression(stack1, expression))
		cout << "\nIt's a valid expression";
	else
		cout << "\nIt's not a valid expression";
	
	cout << "\n\nPress any key to continue....";
	_getch();
	return 0;
}

bool IsValidExpression(CStack& stack1, char exp[])
{
	bool valid = true;
	int left = 0, right = 0;
	for (int i = 0; i < strlen(exp); i++)
	{
		if (exp[i] == '[' || exp[i] == '(' || exp[i] == '{')
		{
			left++;
			stack1.Push(exp, i);
		}
		
		else if (exp[i] == ']' || exp[i] == ')' || exp[i] == '}')
		{
			right++;
			if (stack1.Top(exp, i))
				valid = true;
			else
				return false;
		}
	}
	if (left == right)
		return valid;
	return false;
}
