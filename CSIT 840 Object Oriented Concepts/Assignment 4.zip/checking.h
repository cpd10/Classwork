//Darius Hooks
#ifndef CHECKING_H
#define CHECKING_H
#include "account.h"

class Checking : public Account
{
	private:
		bool overdraftProtection;
	public:
		Checking();
		Checking(Customer, double, bool);
		void makeDeposit(float);
		bool makeWithdrawal(float);
		void adjustBalance();
		void view();
};
#endif