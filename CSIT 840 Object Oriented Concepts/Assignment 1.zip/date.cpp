#include <iostream>
#include "date.h"
#include <string>
using namespace std;

string monthStr[] = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
Date::Date(int mth, int d, int y)
{
	month = mth;;
	day = d;
	year = y;
	valid(month, day, year);
}

void Date::valid(int mn, int dy, int yr)
{
	if (mn > 12 || mn < 1)
	{
		month = 1;
		day = 1;
		year = 2001;
	}

	else if (mn == 1 || mn == 3 || mn == 5 || mn == 7 || mn == 8 || mn == 10 || mn == 12)
	{
		if (dy > monthDays[mn - 1] || dy < 1)
		{
			month = 1;
			day = 1;
			year = 2001;
		}
	}

	else if (mn == 4 || mn == 6 || mn == 9 || mn == 11)
	{
		if (dy > monthDays[mn - 1] || dy < 1)
		{
			month = 1;
			day = 1;
			year = 2001;
		}
	}

	else if (mn == 2)
	{
		if (dy > monthDays[mn - 1] || dy < 1)
		{
			month = 1;
			day = 1;
			year = 2001;
		}
	}

	else if (yr > MAX || yr < MIN)
	{
		month = 1;
		day = 1;
		year = 2001;
	}

	else
	{
		month = mn;
		day = dy;
		year = yr;
	}
}

void Date::printDate(DateFormat date)
{
	if (date == mdy1)
		cout << endl << month << '/' << day << '/' << year;
	else if (date == mdy2)
		cout << endl << monthStr[month - 1] << ' ' << day << ',' << ' ' << year;
	else if (date == dmy)
		cout << endl << day << '-' << monthStr[month - 1].substr(0,3) << '-' << year;
	else if (date == ymd)
		cout << endl << year << '-' << month << '-' << day;
}