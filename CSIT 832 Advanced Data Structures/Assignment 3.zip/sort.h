#ifndef SORT_H
#define SORT_H
const int MAX = 22;

struct Classes
{
	int section;
	int course;
};

class Selection
{
	private:
		int min;
	public:
		void selectionSort(Classes*);
};

class Bubble
{
	private:
		bool swap = false;
	public:
		void bubbleSort(Classes*);
};

class Insertion
{
	public:
		void insertionSort(Classes*);
};

class Merge
{
	private:
		Classes* tempL;
		Classes* tempR;
	public:
		void mergeSort(Classes*, int, int);
		void merge(Classes*, int, int, int);
		~Merge();
};

class Heap
{
	private:
		Classes h[MAX];
	public:
		void heapDown(int, int);
		void heapUp(int, int);
		void swap(Classes&, Classes&);
		void heapSort(Classes*, int);
		
};

class Quick
{
	public:
		void quickSort(Classes*, int, int);
};
#endif
