#ifndef GRAPH_H
#define GRAPH_H
#include "queue.h"

class Graph
{
	private:
		City GraphList[MAX];
		Queue path;
	public:
		Graph(City*);
		void BreadthFirstSearch(City, City);
		void ClearMarks();
		bool IsMarked(City);
		void MarkVertex(City);
		void GetVerticies(City, Queue&);
		void Direct(City, City);
		void Through(City, City);
		bool DirectFound;
		bool ThroughFound;
};
#endif