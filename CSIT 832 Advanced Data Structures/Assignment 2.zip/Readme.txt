==================================================
==================================================
Los Angeles
Connections:
Direct:	
Eugene 748mi
Dallas 1234mi

Through:
Detroit(Dallas) 2219mi
Philadelphia(Dallas, Detroit) 2672mi
New York(Dallas, Detroit) 2727mi
Birmingham 1.(Dallas) 1812mi
	   2.(Dallas, Detroit, New York) 3595mi
===================================================
===================================================
Eugene
Connections:
None
===================================================
===================================================
Detroit
Connections:
Direct:
New York 508mi
Philadelphia 453mi

Through:
Birmingham(New York) 1376mi
===================================================
===================================================
New York
Connections:
Direct:
Birmingham 868mi
===================================================
===================================================
Birmingham
Connections:
None
===================================================
===================================================
Dallas
Connections:
Direct:
Detroit 985mi
Birmingham 578mi

Through:
Philadelphia(Detroit) 1438mi
New York(Detroit) 1493mi
Birmingham(Detroit, New York) 2361mi
===================================================
===================================================
Philadelphia
Connections:
None
===================================================
===================================================