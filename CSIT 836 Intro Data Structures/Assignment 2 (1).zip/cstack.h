#ifndef CSTACK_H
#define CSTACK_H

class CStack
{
	private:
		char data[21];
		int top;
		bool IsEmpty();
		bool IsFull();
	public:
		CStack()
		{
			top = -1;
		}
		void Push(char[], int);
		void Pop(char[]);
		bool Top(char[], int);
};
#endif