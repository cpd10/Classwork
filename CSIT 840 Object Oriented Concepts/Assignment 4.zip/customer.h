//Darius Hooks
#ifndef CUSTOMER_H
#define CUSTOMER_H
#include <string>
using namespace std;

class Customer
{
	private:
		string accountID, name;
	public:
		Customer();
		Customer(string, string);
		void view();
		Customer operator=(const Customer&);
};
#endif