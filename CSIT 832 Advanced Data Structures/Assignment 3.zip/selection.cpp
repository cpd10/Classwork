#include "sort.h"

void Selection::selectionSort(Classes* c)
{
	Classes temp;
	for (int i = 0; i < MAX - 1; i++)
	{
		min = i;

		for (int j = i + 1; j < MAX; j++)
			if (c[j].section < c[min].section)
				min = j;

		if (min != i)
		{
			temp = c[i];
			c[i] = c[min];
			c[min] = temp;
		}
	}
}