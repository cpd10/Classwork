#include <iostream>
#include <fstream>
#include "fraction.h"
using namespace std;
void read(fstream&, Fraction*[]);
void display_all(Fraction*[], int);
void sort(Fraction*[], int);
void doswap(Fraction**, Fraction**);
int search_(const Fraction&, Fraction*[], int);
void read_(fstream&, int, Fraction*[]);
void sum(Fraction*[], int);
void reduce(int&, int&);
void save(fstream&, Fraction [], int);
void delete_all(Fraction*[], int);
const int MAX = 20;
int main()
{
	Fraction* fracptrs[MAX] = { 0 };
	Fraction fracs[MAX], search;
	int size = 0, choice;
	long index;
	char answer, slash;


	fstream fracsFile;
	fracsFile.open("fracs.dat", ios::in | ios::out | ios::binary);
	if (!fracsFile)
		{
			cout << "File does not exist...\n";
		}
	
	do{
		cout << "Choose one of the following:"
			<< "\n1. Read all fractions from file"
			<< "\n2. Enter new fraction"
			<< "\n3. Edit fraction"
			<< "\n4. Sort fractions"
			<< "\n5. Display all fractions"
			<< "\n6. Find a fraction"
			<< "\n7. Read a fraction"
			<< "\n8. Display sum of all fractions"
			<< "\n9. Save fractions to file"
			<< "\n10. Delete all fractions"
			<< "\n11. Quit";
		cout << "\nselection: ";
		cin >> choice;
		cin.ignore();
	switch (choice)
	{
		case 1: cout << endl;
				read(fracsFile, fracptrs);
				break;
		case 2: if (size > MAX)
				break;
				cout << "\nEnter a new fraction? [y/n]: ";
				cin >> answer;
				cin.ignore();
				while (answer == 'y')
				{
					cout << "Enter fraction: ";
					fracptrs[size] = new Fraction;
					cin >> fracptrs[size]->num >> slash >> fracptrs[size]->den;
					size++;
					cout << "\nEnter a new fraction? [y/n]: ";
					cin >> answer;
					cin.ignore();
				}
				cout << endl;
				break;
		case 3: cout << "\nSelect fraction to edit:\n\n";
				display_all(fracptrs, size);
				cout << "\nEnter selection: ";
				cin >> index;
				cin.ignore();
				fracsFile.seekg((index - 1) * sizeof(fracptrs), ios::beg);
				fracsFile.read((char *)&fracptrs, sizeof(fracptrs));
				fracptrs[index - 1] = new Fraction;
				cout << "\nEnter new fraction: ";
				cin >> fracptrs[index - 1]->num >> slash >> fracptrs[index - 1]->den;
				cout << endl;
				fracsFile.seekp((index - 1) * sizeof(fracptrs), ios::beg);
				fracsFile.write((char *)&fracptrs, sizeof(fracptrs));
				break;
		case 4: sort(fracptrs, size);
				break;
		case 5:	cout << endl;
				display_all(fracptrs, size);
				break;
		case 6: sort(fracptrs, size);
				cout << "\nEnter a fraction to search for: ";
				cin >> search.num >> slash >> search.den;
				index = search_(search, fracptrs, size);
				if (index > -1)
					cout << "\nFound at index " << search_(search, fracptrs, size) << endl << endl;
				else
					cout << "\nNot found." << endl << endl;
				break;
		case 7: cout << "\nEnter an index between 0 and " << size - 1 << ": ";
				cin >> index;
				cin.ignore();
				read_(fracsFile, index, fracptrs);
				break;
		case 8: sum(fracptrs, size);
				break;
		case 9: save(fracsFile, fracs, size);
				break;
		case 10: delete_all(fracptrs, size);
				 break;
		case 11: delete_all(fracptrs, size);
				 break;
	}
}while (choice != 11);
	
	fracsFile.close();
	cout << endl;
	system("pause");
	return 0;
}