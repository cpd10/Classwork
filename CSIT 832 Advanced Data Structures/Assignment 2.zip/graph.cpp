#include "graph.h"
#include <iostream>
using namespace std;

Graph::Graph(City* flights)
{
	for (int i = 0; i < MAX; i++)
		GraphList[i] = flights[i];
}

void Graph::BreadthFirstSearch(City dep, City des)
{
	Queue cq;
	Queue vertexQ;
	bool found = false;
	int distance = 0;
	City vertex;
	City item;
	ClearMarks();
	cq.enqueue(GraphList[dep.position]);
	
	
	do
	{
		cq.dequeue(vertex);
		
		if (vertex.name == GraphList[des.position].name)
		{
			Direct(GraphList[dep.position], GraphList[des.position]);
			if(DirectFound)
				cout << "\nDirect Connection between " << GraphList[dep.position].name << " and " << GraphList[des.position].name;
			else
			{
				Through(GraphList[dep.position], GraphList[des.position]);
				cout << "\nNo Direct Connection between " << GraphList[dep.position].name << " and " << GraphList[des.position].name;
				cout << "\nThrough Connection between " << GraphList[dep.position].name << " and " << GraphList[des.position].name;
				/*while (!path.IsEmpty())
					if (!GraphList[path.Front().position].dead)
					{
						path.dequeue(vertex);
						cout << path.Front().name << " ";
						//distance += (GraphList[vertex.position].weight[path.Front().position] + GraphList[path.Front().position].weight[des.position]);
					}
				//cout << distance << " miles";*/
			}
			found = true;
		}

		else
		{
			if (!GraphList[vertex.position].mark)
			{
				MarkVertex(vertex);
				GetVerticies(vertex, vertexQ);

				while (!vertexQ.IsEmpty())
				{
					vertexQ.dequeue(item);
					if (!GraphList[item.position].mark)
						cq.enqueue(item);
				}
			}
		}
	} while (!cq.IsEmpty() && !found);
	if (!found)
		cout << "\nNo Connection between " << GraphList[dep.position].name << " and " << GraphList[des.position].name << endl;
}

void Graph::ClearMarks()
{
	for (int i = 0; i < MAX; i++)
		GraphList[i].mark = false;
}

bool Graph::IsMarked(City vertex)
{
	if (GraphList[vertex.position].mark)
		return true;
	return false;
}

void Graph::MarkVertex(City vertex)
{
	GraphList[vertex.position].mark = true;
}

void Graph::GetVerticies(City vertex, Queue& adjVerticies)
{
	int fromIndex;
	int toIndex;

	for (toIndex = 0; toIndex < MAX; toIndex++)
		if (GraphList[vertex.position].weight[toIndex] > 0)
			adjVerticies.enqueue(GraphList[toIndex]);
	if (adjVerticies.IsEmpty())
		GraphList[vertex.position].dead = true;
	else
		path.enqueue(GraphList[vertex.position]);
}

void Graph::Direct(City dep, City des)
{
	if (GraphList[dep.position].weight[des.position] > 0)
		DirectFound = true;
	else
		DirectFound = false;
}

void Graph::Through(City dep, City des)
{

}