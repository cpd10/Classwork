//Darius Hooks
#include <iostream>
#include "cqueue.h"
#include <conio.h>
using namespace std;

enum LIST {BOOKED, WAITING};
const int LINES = 2;
int Menu();
void addPassenger(Queue*);
void deletePassenger(Queue*);
void showPassengers(Queue*);

int main()
{
	Queue qPassengers[LINES];
	int x, count = 0;
	do
	{
		switch (x = Menu())
		{
		case 1: addPassenger(qPassengers);
			break;
		case 2: deletePassenger(qPassengers);
			break;
		case 3: showPassengers(qPassengers);
			break;
		}
	} while (x != 4);

	cout << "\nPress any key to continue....";
	_getch();
	return 0;
}

int Menu()
{
	int choice;
	cout << "          MENU";
	cout << "\n========================";
	cout << "\n1. Add Passenger";
	cout << "\n2. Delete Passenger";
	cout << "\n3. Show Passengers";
	cout << "\n4. Exit\n";
	cout << "\nEnter Choice: ";
	cin >> choice;
	cin.ignore();
	return choice;
}

void addPassenger(Queue* qPassengers)
{
	if (qPassengers[BOOKED].IsFull() && qPassengers[WAITING].IsFull())
	{
		cout << "\nSorry. Plane and waiting list fully booked. Try again later.\n\n";
		return;
	}
	Passenger p;
	cout << "\nEnter name: ";
	cin.get(p.name, 80, '\n');
	cin.ignore();
	if (!qPassengers[BOOKED].IsFull())
	{
		cout << "Booking " << p.name << " on the flight.\n\n";
		qPassengers[BOOKED].enqueue(p);
	}
	else if (qPassengers[BOOKED].IsFull() && !qPassengers[WAITING].IsFull())
	{
		cout << "\nSorry. Plane fully booked. Adding " << p.name << " to waiting list.\n\n";
		qPassengers[WAITING].enqueue(p);
	}
}

void deletePassenger(Queue* qPassengers)
{
	if (qPassengers[BOOKED].IsEmpty())
	{
		cout << "\nNo passengers to delete.\n\n";
		return;
	}
	else if (qPassengers[WAITING].IsEmpty())
	{
		cout << "\nRemoving " << qPassengers[BOOKED].Front().name << " from booked passengers.\n";
		qPassengers[BOOKED].dequeue();
		cout << "\nNo passengers on waiting list.\n\n";
		return;
	}
	else if (!qPassengers[BOOKED].IsEmpty ())
	{
		cout << "\nRemoving " << qPassengers[BOOKED].Front().name << " from booked passengers.\n";
		qPassengers[BOOKED].dequeue();
		
		cout << "\nAdding " << qPassengers[WAITING].Front().name << " from waiting list.\n\n";
		qPassengers[BOOKED].enqueue(qPassengers[WAITING].Front());
		qPassengers[WAITING].dequeue();
	}
	
}

void showPassengers(Queue* qPassengers)
{
	Queue temp[LINES];
	temp[BOOKED] = qPassengers[BOOKED];
	temp[WAITING] = qPassengers[WAITING];
	if (!qPassengers[BOOKED].IsEmpty())
	{
		cout << "\n     Booked Passengers";
		cout << "\n===========================\n";
		while(!temp[BOOKED].IsEmpty())
		{
			cout << temp[BOOKED].Front().name << endl;
			temp[BOOKED].dequeue();
		}
			

		if (!qPassengers[WAITING].IsEmpty())
		{
			cout << "\n     Waiting List";
			cout << "\n=======================\n";
			while(!temp[WAITING].IsEmpty())
			{
				cout << temp[WAITING].Front().name << endl;
				temp[WAITING].dequeue();
			}
		}
		else if (qPassengers[WAITING].IsEmpty())
			cout << "\nNo passengers on waiting list.\n\n";
	}
	else
		cout << "\nNo passengers.\n\n";
}