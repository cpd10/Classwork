#include <iostream>
#include "date.h"
#include <conio.h>
using namespace std;
int main()
{
	Date d1;
	int m, d, y;
	cout << "Enter month, day and year separated by spaces: ";
	cin >> m >> d >> y;
	
	d1.setDate(m, d, y);
	d1.printDate();

	cout << "\nPress any key to continue...";
	_getch();
	return 0;
}