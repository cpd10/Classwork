#ifndef PQTYPE_H
#define PQTYPE_H
#include "heap.h"

class PQType
{
	public:
		PQType(int);
		~PQType();
		void MakeEmpty();
		bool IsEmpty();
		bool IsFull();
		void Enqueue(Printer newItem);
		void Dequeue(Printer&);
	private:
		int length;
		HeapType items;
		int maxItems;
};

#endif
