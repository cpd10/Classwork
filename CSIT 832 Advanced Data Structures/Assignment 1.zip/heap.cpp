#include "heap.h"

void HeapType::Swap(HeapType& a, HeapType& b)
{
	HeapType temp;
	temp = a;
	a = b;
	b = temp;
}

void HeapType::ReheapDown(int root, int bottom)
{
	int  maxChild;
	int  rightChild;
	int  leftChild;

	leftChild = root * 2 + 1;
	rightChild = root * 2 + 2;
	if (leftChild <= bottom)
	{
		if (leftChild == bottom)
			maxChild = leftChild;

		else
		{
			if (elements[leftChild].priorityElements < elements[rightChild].priorityElements)
				maxChild = rightChild;
			else if (elements[leftChild].priorityElements > elements[rightChild].priorityElements)
				maxChild = leftChild;
			
			else if (elements[leftChild].priorityElements == elements[rightChild].priorityElements)
			{
				if (elements[leftChild].numElements > elements[rightChild].numElements)
					maxChild = rightChild;
				else
					maxChild = leftChild;
			}
		}

		if (elements[root].priorityElements < elements[maxChild].priorityElements)
		{
			Swap(elements[root], elements[maxChild]);
			ReheapDown(maxChild, bottom);
		}

		else if (elements[root].priorityElements == elements[maxChild].priorityElements)
		{
			if (elements[root].numElements > elements[maxChild].numElements)
			{
				Swap(elements[root], elements[maxChild]);
				ReheapDown(maxChild, bottom);
			}
		}
	}
}

void HeapType::ReheapUp(int root, int bottom)
{
	int parent;

	if (bottom > root)
	{
		parent = (bottom - 1) / 2;
		if (elements[parent].priorityElements < elements[bottom].priorityElements)
		{
			Swap(elements[parent], elements[bottom]);
			ReheapUp(root, parent);
		}
		else if (elements[parent].priorityElements == elements[bottom].priorityElements)
		{
			if (elements[parent].numElements > elements[bottom].numElements)
			{
				Swap(elements[parent], elements[bottom]);
				ReheapUp(root, parent);
			}
		}
	}
}
