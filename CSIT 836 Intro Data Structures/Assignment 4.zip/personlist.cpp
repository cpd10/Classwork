//Darius Hooks
#include "personlist.h"
#include <iostream>
using namespace std;

PersonList::PersonList()
{
	head = NULL;
}

PersonList::~PersonList()
{
	PersonRec* nextPtr;
	while (head != NULL)
	{
		nextPtr = head->link;
		delete head;
		head = nextPtr;
	}
}

void PersonList::AddToList()
{
	char aName[20];
	int aBribe;
	PersonRec* currPtr;
	cout << "\nEnter the person's name: ";
	cin.get(aName, 20, '\n');
	cin.ignore();
	cout << "Enter the person's contribution: ";
	cin >> aBribe;

	if (head == NULL)
	{
		head = new PersonRec;
		strcpy_s(head->name, aName);
		head->bribe = aBribe;
		head->link = NULL;
	}
	
	else
	{
		currPtr = head;
		while (currPtr->link != NULL)
			currPtr = currPtr->link;
		currPtr->link = new PersonRec;
		strcpy_s(currPtr->link->name, aName);
		currPtr->link->bribe = aBribe;
		currPtr->link->link = NULL;

		Swap(currPtr->link);
	}
}

void PersonList::ViewList()
{
	if (head == NULL)
		cout << "\nList is empty\n";
	else
	{
		cout << "\n\tName & Contribution";
		cout << "\n==================================\n";
		int count = 0;
		PersonRec* currPtr;
		currPtr = head;
		while (currPtr != NULL)
		{
			cout << count + 1 << ". " << currPtr->name << " $" << currPtr->bribe << endl;
			currPtr = currPtr->link;
			count++;
		}
	}
}

void PersonList::Swap(PersonRec* currBribe)
{
	char tempName[20];
	int tempBribe;
	bool swap;
	PersonRec* currPtr;
	currPtr = head;
	do
	{
		swap = false;
		while (currPtr->link != NULL)
		{
			if (currBribe->bribe > currPtr->bribe)
			{
				strcpy_s(tempName, currPtr->name);
				tempBribe = currPtr->bribe;

				strcpy_s(currPtr->name, currBribe->name);
				currPtr->bribe = currBribe->bribe;

				strcpy_s(currBribe->name, tempName);
				currBribe->bribe = tempBribe;

				swap = true;
			}
			currPtr = currPtr->link;
		}
	} while (swap); 
}