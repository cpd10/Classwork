#include "sort.h"

void Quick::quickSort(Classes* c, int left, int right)
{
	int i = left, j = right;
	Classes tmp;
	Classes pivot = c[(left + right) / 2];

	while (i <= j) 
	{
		while (c[i].section < pivot.section)
			i++;
		while (c[j].section > pivot.section)
			j--;
		if (i <= j)
		{
			tmp = c[i];
			c[i] = c[j];
			c[j] = tmp;
			i++;
			j--;
		}
	}

	if (left < j)
		quickSort(c, left, j);
	if (i < right)
		quickSort(c, i, right);
}