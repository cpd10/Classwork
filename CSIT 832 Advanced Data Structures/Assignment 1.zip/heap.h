#ifndef HEAP_H
#define HEAP_H

struct Printer	//To hold the data added to the queue
{
	int job;		//Job Number
	int priority;	//Who the job is for
};

struct HeapType
{
	void ReheapDown(int root, int bottom);
	void ReheapUp(int root, int bottom);
	void Swap(HeapType&, HeapType&);

	HeapType* elements; //array to be allocated dynamically
	int numElements;		//Job Number
	int priorityElements;	//Who the job is for
};

#endif