#include "sort.h"

void Insertion::insertionSort(Classes* c)
{
	Classes temp;
	int j;
	for (int i = 0; i < MAX; i++)
	{
		j = i;

		while (j > 0 && c[j].section < c[j - 1].section)
		{
			temp = c[j];
			c[j] = c[j - 1];
			c[j - 1] = temp;
			j--;
		}
	}
}