#ifndef QUEUE_H
#define QUEUE_H
#include <string>
using namespace std;
const int MAX = 7;
struct City
{
	int position;
	string name;
	int weight[MAX];
	bool mark;
	bool dead = false;
};

class Queue
{
	private:
		int front, rear;
		City c[MAX];
	public:
		Queue();
		bool IsEmpty();
		bool IsFull();
		void MakeEmpty();
		void enqueue(City);
		void dequeue(City&);
		City Front();
};

#endif
