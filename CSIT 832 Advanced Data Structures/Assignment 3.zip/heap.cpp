#include "sort.h"
#include <iostream>
using namespace std;


void Heap::swap(Classes& a, Classes& b) 
{ 
	Classes temp;
	temp = a;
	a = b;  
	b = temp; 
}

void Heap::heapDown(int root , int bottom)
{
	int max;
	int left = 2 * root + 1;
	int right = 2 * root + 2;

	if (left <= bottom)
	{
		if (left == bottom)
			max = left;

		else
		{
			if (h[left].section < h[right].section)
				max = right;
			else if (h[left].section > h[right].section)
				max = left;
		}

		if (h[root].section < h[max].section)
		{
			swap(h[root], h[max]);
			heapDown(max, bottom);
		}
	}
}

void Heap::heapUp(int root, int bottom)
{
	int parent;

	if (bottom > root)
	{
		parent = (bottom - 1) / 2;
		if (h[parent].section > h[bottom].section)
		{
			swap(h[parent], h[bottom]);
			heapUp(root, parent);
		}
	}
}

void Heap::heapSort(Classes*c, int size)
{
	Classes t;
	Classes temp[MAX];
	int k = size;
	for (int i = 0; i < size; i++)
	{
		h[i] = c[i];
		heapUp(0, i);
	}

	/*for (int j = 0; j < size; j++)
	{
		t = h[0];
		swap(t, h[(size - 1) - j]);
		heapUp(0, (size - 1) - j);
		h[k - 1] = t;
	}*/

	for (int i = 0; i < size; i++)
		c[i] = h[i];
	
}