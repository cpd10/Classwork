//Darius Hooks
#include <iostream>
#include "cqueue.h"
using namespace std;

Queue::Queue()
{
	front = MAX - 1;
	rear = MAX - 1;
}

bool Queue::IsEmpty()
{
	if (front == rear)
		return true;
	return false;
}

bool Queue::IsFull()
{
	if ((rear + 1) % MAX == front)
		return true;
	return false;
}

void Queue::enqueue(Passenger p)
{
	if (IsFull())
		return;
	else
	{
		rear = (rear + 1) % MAX;
		strcpy_s(passengers[rear].name, p.name);
	}
}

void Queue::dequeue()
{
	if (IsEmpty())
		return;
	else
		front = (front + 1) % MAX;
}

Passenger Queue::Front()
{
	return passengers[(front + 1) % MAX];
}