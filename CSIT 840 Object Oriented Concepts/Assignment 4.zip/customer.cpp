//Darius Hooks
#include "customer.h"
#include <iostream>

Customer::Customer()
{
	accountID = "";
	name = "";
}

Customer::Customer(string n, string id)
{
	accountID = id;
	name = n;
}

void Customer::view()
{
	cout << "\nName: " << name << "\nAccount Number: " << accountID;
}

Customer Customer::operator=(const Customer& c)
{
	accountID = c.accountID;
	name = c.name;
	return *this;
}