//Darius Hooks
#include "checking.h"
#include <iostream>
using namespace std;

const float SERVICE = 10;
const float MIN = 1000;

Checking::Checking() : Account()
{
	overdraftProtection = false;
}

Checking::Checking(Customer c, double start, bool over) : Account(start, c)
{
	overdraftProtection = over;
}

void Checking::makeDeposit(float deposit)
{
	Account::makeDeposit(deposit);
}

bool Checking::makeWithdrawal(float withdraw)
{
	if (withdraw > balance && !overdraftProtection)
		return false;
	Account::makeWithdrawal(withdraw);
	return true;
}

void Checking::adjustBalance()
{
	if (balance < MIN)
		balance -= SERVICE;
}

void Checking::view()
{
	cout << "\nChecking Account:";
	Account::view();
}