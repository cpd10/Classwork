#include <iostream>
#include <conio.h>
#include <fstream>
#include "hash.h"
using namespace std;
int menu();
void read();

int main()
{
	Hash h;
	Student s;
	int choice;
	string sid;
	ifstream file("students.txt");
	for (int i = 0; i < MAX_STUDENTS; i++)
	{
		file >> s.id;
		file.seekg(1, ios::cur);
		getline(file, s.name);
		h.insert(s.id, s.name);
	}
	file.close();
	do
	{
		switch (choice = menu())
		{
			case 1: cout << "\nEnter 4 digit ID: ";
					cin >> sid;
					cout << endl << h.retrieve(sid);
		}

	} while (choice != 2);
	cout << "\nPress any key to continue...";
	_getch();
	return 0;
}

int menu()
{
	int sel;
	cout << "1. Find student by ID";
	cout << "\n2. Exit";
	cout << "\nEnter Selection: ";
	cin >> sel;
	return sel;
}