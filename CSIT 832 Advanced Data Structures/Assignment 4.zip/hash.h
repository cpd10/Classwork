#ifndef HASH_H
#define HASH_H
#include <string>
using namespace std;

const int MAX_TABLE = 100;
const int MAX_STUDENTS = 25;
const int MAX_ID = 4;

struct Student
{
	string id;
	string name;
};

class Hash
{
	private:
		Student* studs;
	public:
		Hash();
		~Hash();
		void insert(string, string);
		string retrieve(string);
};

#endif
