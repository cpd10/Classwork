#include <iostream>
#include "date.h"
using namespace std;

void Date::setDate(int mn, int dy, int yr)
{
	if (mn > 12 || mn < 1)
	{
		month = 9;
		day = 2;
		year = 2008;
	}

	else if (dy > 31 || dy < 1)
	{
		month = 9;
		day = 2;
		year = 2008;
	}

	else if (yr > 2008 || yr < 1900)
	{
		month = 9;
		day = 2;
		year = 2008;
	}

	else
	{
		month = mn;
		day = dy;
		year = yr;
	}
}

void Date::printDate()
{
	cout << endl << month << '/' << day << '/' << year << endl;
}