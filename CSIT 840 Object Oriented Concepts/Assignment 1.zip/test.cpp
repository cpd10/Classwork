#include <iostream>
#include "date.h"
#include <conio.h>
using namespace std;
void setDateValues(int&, int&, int&);
int main()
{
	int mth, day, yr;

	setDateValues(mth, day, yr);
	Date d1(mth, day, yr);
	
	cout << "\nDate is:\n";
	d1.printDate(mdy1);
	d1.printDate(mdy2);
	d1.printDate(dmy);
	d1.printDate(ymd);
	
	cout << "\n\nPress any key to continue....";
	_getch();
	return 0;
}

void setDateValues(int& m, int& d, int& y)
{
	cout << "Enter month: ";
	cin >> m;
	cout << "Enter day: ";
	cin >> d;
	cout << "Enter year: ";
	cin >> y;
}
