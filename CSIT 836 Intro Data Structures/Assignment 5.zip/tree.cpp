//Darius Hooks
#include "tree.h"
#include <iostream>
using namespace std;

PersonRec::PersonRec(char* n, int b, PersonRec* left = NULL, PersonRec* right = NULL)
{
	strcpy_s(name, n);
	bribe = b;
	lChild = left;
	rChild = right;
}

CTree::CTree()
{
	root = NULL;
}

CTree::~CTree()
{
	if (root != NULL)
		DeleteTree(root);
}

void CTree::Add()
{
	char aName[40];
	int aBribe;
	cout << "\nEnter the person's name: ";
	cin.get(aName, 40, '\n');
	cin.ignore();
	cout << "\nEnter the person's contribution: ";
	cin >> aBribe;

	if (root == NULL)
		root = new PersonRec(aName, aBribe);
	else
		AddItem(root, aName, aBribe);
	/*ptr = root;
	while (ptr != NULL)
	{
	if (ptr->bribe < aBribe)
	{
	if (ptr->lChild == NULL)
	ptr->lChild = new PersonRec(aName, aBribe);
	else
	ptr = ptr->lChild;
	}

	else if (ptr->bribe > aBribe)
	{
	if (ptr->rChild == NULL)
	ptr->rChild = new PersonRec(aName, aBribe);
	else
	ptr = ptr->rChild;
	}

	else
	{
	cout << "\nThis bribe amount has already been paid.";
	return;
	}
	} */
}

void CTree::View()
{
	if (root == NULL)
		cout << "\nList is empty\n";
	else
	{
		cout << "\n\tName & Contribution";
		cout << "\n==================================\n";
		DisplayTree(root);
	}
}

void CTree::DisplayTree(PersonRec* ptr)
{
	if (ptr != NULL)
	{
		DisplayTree(ptr->rChild);
		cout << ptr->name << " $" << ptr->bribe << endl;
		DisplayTree(ptr->lChild);
	}
}

void CTree::DeleteTree(PersonRec*& ptr)
{
	if (ptr != NULL)
	{
		DeleteTree(ptr->lChild);
		DeleteTree(ptr->rChild);
		delete ptr;
	}
}

void CTree::AddItem(PersonRec*& ptr, char* n, int b)
{
	if (ptr != NULL)
	{
		if (ptr->bribe > b)
		{
			if (ptr->lChild == NULL)
				ptr->lChild = new PersonRec(n, b);
			else
				AddItem(ptr->lChild, n, b);
		}

		else if (ptr->bribe < b)
		{
			if (ptr->rChild == NULL)
				ptr->rChild = new PersonRec(n, b);
			else
				AddItem(ptr->rChild, n, b);
		}

		else
		{
			cout << "\nThis bribe amount has already been paid.";
			return;
		}
	}
}