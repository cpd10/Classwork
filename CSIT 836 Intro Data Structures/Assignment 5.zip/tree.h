//Darius Hooks
#ifndef TREE_H
#define TREE_H

struct PersonRec
{
	char name[20];
	int bribe;
	PersonRec* lChild;
	PersonRec* rChild;
	PersonRec(char*, int, PersonRec*, PersonRec*);
};

class CTree
{
private:
	PersonRec* root;
	void DisplayTree(PersonRec*);
	void DeleteTree(PersonRec*&);
	void AddItem(PersonRec*&, char*, int);
public:
	CTree();
	~CTree();
	void Add();
	void View();
};
#endif