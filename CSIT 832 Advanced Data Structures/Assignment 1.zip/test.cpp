//Darius Hooks
#include <iostream>
#include <conio.h>
#include "heap.h"
#include "pqtype.h"
using namespace std;
int Menu();
int Status_Check(char); //Assigns value for who the job is for
enum Priority { STUDENT, TA, INSTRUCTOR };

int main()
{
	int choice, job_count = 0;
	char status;
	PQType pq(100);
	PQType temp(100);
	Printer p;

	do
	{
		switch (choice = Menu())
		{
			case 1:	if(pq.IsFull())
						cout << "\nQueue is full\n\n";
					else
					{
						job_count++;
						cout << "\nInstructor (I or i)\nTA (T or t)\nStudent (S or s)? ";
						cin >> status;
						cout << endl;
						p.job = job_count;
						p.priority = Status_Check(status);
						pq.Enqueue(p);
					}
					break;
			
			case 2: if (pq.IsEmpty())
						cout << "\nNo print jobs in queue\n\n";
					else
					{
						pq.Dequeue(p);
						switch (p.priority)
						{
							case 0:	cout << "\nNow printing job #" << p.job << ": Student\n\n";
									break;
							case 1:	cout << "\nNow printing job #" << p.job << ": TA\n\n";
									break;
							case 2:	cout << "\nNow printing job #" << p.job << ": Instructor\n\n";
									break;
						}
						
					}
					break;
			
			case 3: if (pq.IsEmpty())
						cout << "\nNo print jobs in queue\n\n";
					else
					{
						Printer temp[100];
						int count = 0;
						cout << "\nPrint Jobs";
						cout << "\n------------";
						while (!pq.IsEmpty())
						{
							pq.Dequeue(p);
							switch (p.priority)
							{
								case 0:	cout << "\njob #" << p.job << ": Student";
										break;
								case 1:	cout << "\njob #" << p.job << ": TA";
										break;
								case 2:	cout << "\njob #" << p.job << ": Instructor";
										break;
							}
							temp[count].job = p.job;
							temp[count].priority = p.priority;
							count++;
						}
						
						for (int i = 0; i < count; i++)	//Restores everything that was deleted while viewing
							pq.Enqueue(temp[i]);
						cout << "\n\n";
					}
					break;

		}
	} while (choice != 4);
	
	cout << "\nPress any key to continue...";
	_getch();
	return 0;
}

int Menu()
{
	int sel;
	cout << "Printer queue"
		<< "\n==============="
		<< "\n1. Add job"
		<< "\n2. Print job"
		<< "\n3. View jobs"
		<< "\n4. Exit"
		<< "\nEnter choice: ";
	cin >> sel;
	return sel;
}

int Status_Check(char status)
{
	if (toupper(status) == 'I')
		return INSTRUCTOR;
	else if (toupper(status) == 'T')
		return TA;
	else
		return STUDENT;
}