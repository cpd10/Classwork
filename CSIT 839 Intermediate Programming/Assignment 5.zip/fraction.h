#ifndef FRACS_H
#define FRACS_H
struct Fraction
{
	int num, den;
};
#endif