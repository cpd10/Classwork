//Darius Hooks
#include "account.h"
#include <iostream>

Account::Account()
{
	balance = 0;
	cust.Customer::Customer();
}

Account::Account(float bal, Customer c)
{
	balance = bal;
	cust = c;
}

void Account::makeDeposit(float deposit)
{
	balance += deposit;
}

bool Account::makeWithdrawal(float withdraw)
{
	balance -= withdraw;
	return true;
}

float Account::getBalance()
{
	return balance;
}

void Account::view()
{
	cust.view();
	cout << "\nAccount Balance: $" << getBalance();
}