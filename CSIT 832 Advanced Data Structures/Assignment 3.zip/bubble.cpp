#include "sort.h"

void Bubble::bubbleSort(Classes* c)
{
	Classes temp;
	for (int i = 0; i < MAX; i++)
		for (int j = 0; j < MAX - 1; j++)
			if (c[j].section > c[j + 1].section)
			{
				temp = c[j];
				c[j] = c[j + 1];
				c[j + 1] = temp;
				swap = true;
			}
}