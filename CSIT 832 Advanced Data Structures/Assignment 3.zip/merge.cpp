#include "sort.h"

Merge::~Merge()
{
	delete [] tempL;
	delete [] tempR;
}

void Merge::merge(Classes* c, int left, int middle, int right)
{
	int i, j, k;
	int n1 = middle - left + 1;
	int n2 = right - middle;

	tempL = new Classes[n1];
	tempR = new Classes[n2];

	for (i = 0; i < n1; i++)
		tempL[i] = c[left + i];
	for (j = 0; j < n2; j++)
		tempR[j] = c[middle + 1 + j];

	i = 0;
	j = 0;
	k = left;

	while (i < n1 && j < n2)
	{
		if (tempL[i].section <= tempR[j].section)
		{
			c[k] = tempL[i];
			i++;
		}
		else
		{
			c[k] = tempR[j];
			j++;
		}
		k++;
	}

	while (i < n1)
	{
		c[k] = tempL[i];
		i++;
		k++;
	}

	while (j < n2)
	{
		c[k] = tempR[j];
		j++;
		k++;
	}
}

void Merge::mergeSort(Classes* c, int left, int right)
{
	int middle;
	if (left < right)
	{
		middle = left + (right - left) / 2;
		mergeSort(c, left, middle);
		mergeSort(c, middle + 1, right);
		merge(c, left, middle, right);
	}
}