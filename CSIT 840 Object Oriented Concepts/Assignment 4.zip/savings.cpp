//Darius Hooks
#include "savings.h"
#include <iostream>
using namespace std;

const double REWARD = 100;

Savings::Savings() : Account()
{
	interestRate = 0;
}

Savings::Savings(Customer c, double start, double rate) : Account(start, c)
{
	interestRate = rate;
}

void Savings::makeDeposit(float deposit)
{
	if (deposit >= 10000)
		deposit += REWARD;
	Account::makeDeposit(deposit);
}

bool Savings::makeWithdrawal(float withdraw)
{
	if (withdraw > balance)
		return false;
	Account::makeWithdrawal(withdraw);
	return true;
}

void Savings::adjustBalance()
{
	balance += interestRate * balance;
}

void Savings::view()
{
	cout << "\nSavings Account:";
	Account::view();
}