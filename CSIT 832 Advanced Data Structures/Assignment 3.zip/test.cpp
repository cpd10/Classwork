#include <iostream>
#include <fstream>
#include "sort.h"
using namespace std;
int menu();
void loadFile(Classes*);
void display(Classes*);

int main()
{
	char choice;
	Classes c[MAX];
	Bubble bubble;
	Selection selection;
	Insertion insertion;
	Merge _merge;
	Quick quick;
	Heap heap;
	do
	{
		switch (choice = toupper(menu()))
		{
			case 'A':	loadFile(c);
						selection.selectionSort(c);
						display(c);
						break;
			case 'B':	loadFile(c);
						bubble.bubbleSort(c);
						display(c);
						break;
			case 'C':	loadFile(c);
						insertion.insertionSort(c);
						display(c);
						break;
			case 'D':	loadFile(c);
						heap.heapSort(c, MAX);
						display(c);
						break;
			case 'E':	loadFile(c);
						quick.quickSort(c, 0, MAX - 1);
						display(c);
						break;
			case 'F':	loadFile(c);
						_merge.mergeSort(c, 0, MAX - 1);
						display(c);
						break;
		}
	} while (choice != 'G');
	return 0;
}

int menu()
{
	char sel;
	cout << "\nA. Selection"
		<< "\nB. Bubble"
		<< "\nC. Insertion"
		<< "\nD. Heap"
		<< "\nE. Quick"
		<< "\nF. Merge"
		<< "\nG. Exit"
		<< "\nSelection: ";
	cin >> sel;
	cout << "\n";
	return sel;
}

void loadFile(Classes* c)
{
	ifstream file;
	file.open("classes.txt");
	for (int i = 0; i < MAX; i++)
		file >> c[i].course >> c[i].section;
	file.close();
}

void display(Classes* c)
{
	for (int i = 0; i < MAX; i++)
		cout << c[i].section << " " << c[i].course << "\n";
}