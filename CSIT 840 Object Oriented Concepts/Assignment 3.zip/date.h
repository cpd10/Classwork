//Darius Hooks
#ifndef DATE_H
#define DATE_H
#include <iostream>
using namespace std;

class Date
{
	private:
		int month, day, year;
	public:
		Date();
		Date(const Date&);
		bool operator==(const Date&);
		bool operator>(const Date&);
		Date operator-(const Date&);
		Date operator=(const Date&);
		friend istream& operator>>(istream&, Date&);
		friend ostream& operator<<(ostream&, Date&);
};
#endif