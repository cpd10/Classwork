#include <iostream>
#include "cstack.h"
using namespace std;

bool CStack::IsEmpty()
{
	if (strcmp(data, "") == 0)
		return true;
	return false;
}

bool CStack::IsFull()
{
	if (strlen(data) < 20)
		return true;
	return false;
}

void CStack::Push(char exp[], int i)
{
	if (IsFull())
	{
		cout << "\nStack is full";
		exit(1);
	}
	else
	{
		top++;
		data[top] = exp[i];
	}
}

void CStack::Pop(char exp[])
{
	if (IsEmpty())
	{
		cout << "\nStack is empty";
		exit(1);
	}
	else
		top--;
}

bool CStack::Top(char exp[], int i)
{
	if (exp[i] == ']')
	{
		if (data[top] == '[')
		{
			Pop(exp);
			return true;
		}
	}
	
	else if (exp[i] == ')')
	{
		if (data[top] == '(')
		{
			Pop(exp);
			return true;
		}
	}
	
	else if (exp[i] == '}')
	{
		if (data[top] == '{')
		{
			Pop(exp);
			return true;
		}
	}
	return false;
}