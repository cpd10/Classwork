//Darius Hooks
#ifndef ACCOUNT_H
#define ACCOUNT_H
#include "customer.h"

class Account
{
	protected:
		float balance;
		Customer cust;
	public:
		Account();
		Account(float, Customer);
		virtual void makeDeposit(float);
		virtual bool makeWithdrawal(float);
		float getBalance();
		virtual void view();
		virtual void adjustBalance() = 0;
};
#endif