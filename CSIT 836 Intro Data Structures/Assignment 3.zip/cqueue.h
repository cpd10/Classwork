//Darius Hooks
#ifndef CQUEUE_H
#define CQUEUE_H
const int MAX = 4;
struct Passenger
{
	char name[80];
};

class Queue
{
	private:
		int front, rear;
		Passenger passengers[MAX];
	public:
		Queue();
		bool IsEmpty();
		bool IsFull();
		void enqueue(Passenger);
		void dequeue();
		Passenger Front();
};
#endif