//Darius Hooks
#ifndef SAVINGS_H
#define SAVINGS_H
#include "account.h"

class Savings : public Account
{
	private:
		float interestRate;
	public:
		Savings();
		Savings(Customer, double, double);
		void makeDeposit(float);
		bool makeWithdrawal(float);
		void adjustBalance();
		void view();
};

#endif