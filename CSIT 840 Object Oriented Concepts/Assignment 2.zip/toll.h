//Darius Hooks
#ifndef TOLL_H
#define TOLL_H

class TollBooth
{
	private:
		int m_nPayingStu, m_nDeadbeatStu; 
		static int m_nCourseCount;
	public:
		static int getCourseCount();
		void setStudents();
		void getStudents(float&);
		void displayCourse();
};
#endif