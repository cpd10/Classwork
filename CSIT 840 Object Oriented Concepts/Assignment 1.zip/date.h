#ifndef DATE_H
#define	DATE_H

enum DateFormat {mdy1, mdy2, dmy, ymd};
const int MIN = 1900;
const int MAX = 2020;
const int monthDays[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

class Date
{
	int month, day, year;
public:
	Date(int, int, int);
	void valid(int, int, int);
	void printDate(DateFormat);
};
#endif