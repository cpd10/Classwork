#include "queue.h"

Queue::Queue()
{
	front = MAX - 1;
	rear = MAX - 1;
}

bool Queue::IsEmpty()
{
	if (front == rear)
		return true;
	return false;
}

bool Queue::IsFull()
{
	if ((rear + 1) % MAX == front)
		return true;
	return false;
}

void Queue::enqueue(City p)
{
	if (IsFull())
		return;
	else
	{
		rear = (rear + 1) % MAX;
		//strcpy_s(passengers[rear].name, p.name);
		c[rear] = p;
	}
}

void Queue::dequeue(City& p)
{
	if (IsEmpty())
		return;
	else
	{
		front = (front + 1) % MAX;
		p = c[front];
	}
}

City Queue::Front()
{
	return c[(front + 1) % MAX];
}

void Queue::MakeEmpty()
{
	front = MAX - 1;
	rear = MAX - 1;
}