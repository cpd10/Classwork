#include "hash.h"
#include <iostream>
using namespace std;

Hash::Hash()
{
	studs = new Student[MAX_TABLE];
	for (int i = 0; i < MAX_TABLE; i++)
	{
		studs[i].id = "";
		studs[i].name = "";
	}
}

Hash::~Hash()
{
	delete[] studs;
}

void Hash::insert(string sid, string n)
{
	string temp = sid;
	int hash;
	temp.erase(0, 2);
	hash = stoi(temp);
	if (studs[hash].name == "")
	{
		studs[hash].id = sid;
		studs[hash].name = n;
	}
	else
	{
		while (studs[hash].name != "")
			hash = (hash + 1) % MAX_TABLE;
		studs[hash].id = sid;
		studs[hash].name = n;
	}
}

string Hash::retrieve(string sid)
{
	string temp = sid;
	int hash;
	temp.erase(0, 2);
	hash = stoi(temp);
	int start = hash;

	if (studs[hash].id == sid)
		return studs[hash].name + "\n\n";
	else
		while (studs[hash].id != sid)
		{
			hash = (hash + 1) % MAX_TABLE;
			if(hash == start)
				return "No student has that ID\n\n";
			if(studs[hash].id == sid)
				return studs[hash].name + "\n\n";
		}
	
}