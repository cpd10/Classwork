//Darius Hooks
#include <iostream>
#include <conio.h>
#include "date.h"
using namespace std;
int main()
{
	Date date1;
	Date date2 = date1; //copy constructor called

	cout << "Initial date values\n";
	cout << "Date 1 is ";
	cout << date1 << endl;
	cout << "Date 2 is ";
	cout << date2 << endl;
	cout << "Enter a date no earlier than 1800\n";
	cin >> date1;
	cout << "\nEnter another date no earlier than 1800\n";
	cin >> date2;
	cout << "\nRevised date values\n";
	cout << "\nDate 1 is ";
	cout << date1 << endl;
	cout << "\nDate 2 is ";
	cout << date2 << endl;

	if (date1 == date2)
		cout << "\nThe two input dates are the same\n";
	else if (date1 > date2)
	{
		cout << "\nDate 1 is later in time than Date 2 by ";
		Date temp = date1 - date2;
		cout << temp << endl;
	}
	else
	{
		cout << "\nDate 2 is later in time than Date 1 by ";
		Date temp = date2 - date1;
		cout << temp << endl;
	}

	Date date3, date4;
	date4 = date3 = date2; //overloaded assignment operator called
	cout << "\nAfter the assignment date4 = date3 = date2\n";
	cout << "\nDate 3 is " << date3 << " and Date 4 is " << date4 << endl;
	
	cout << "\nPress any key to continue...";
	_getch();
	return 0;
}