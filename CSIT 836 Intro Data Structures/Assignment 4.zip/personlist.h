//Darius Hooks
#ifndef PERSON_H
#define PERSON_H

struct PersonRec
{
	char name[20];
	int bribe;
	PersonRec* link;
};

class PersonList 
{
	public:
		PersonList();
		~PersonList();
		void ViewList();
		void AddToList();

	private:
		PersonRec* head;
		void Swap(PersonRec*);
};
#endif