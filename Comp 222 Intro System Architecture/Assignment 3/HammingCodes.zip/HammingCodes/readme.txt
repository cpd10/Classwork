Instructions for using input.txt
On the k200 machine, place input.txt in the same directory as your program
After compiling your program, run the command:
	./yourProgram <input.txt> output.txt

Your program's output will be printed and saved to output.txt
If your program is working, your output should match ProgramOutput.txt*

ReducedOutput.txt contains binary strings, and checks for both even and odd parity. It also lists if there are errors, where the errors are located, and the corrected string

All outputs in ReducedOutput.txt correspond with the inputs from input.txt

* Note: if you are using special characters to make your terminal output bold text, your output.txt file will have characters similar to "", these are nothing to worry about
