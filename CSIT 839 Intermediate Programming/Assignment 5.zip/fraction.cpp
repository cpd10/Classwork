#include <iostream>
#include <fstream>
#include "fraction.h"
using namespace std;

void read(fstream& fracsFile, Fraction* fracptrs[])
{
	if (!fracsFile)
		cout << "File does not exist..." << endl << endl;
	else
	{
		for (int i = 0; i < sizeof(fracptrs); i++)
			fracsFile.read((char*)&fracptrs[i], sizeof(fracptrs[i]));
		cout << "That's all the information in the file." << endl << endl;
	}
}

void display_all(Fraction* fracptrs[], int size)
{
	if (size == 0)
		cout << "There are no fractions to display." << endl << endl;
	for (int i = 0; i < size; i++)
		cout << i + 1 << ". " << fracptrs[i]->num << '/' << fracptrs[i]->den << endl;
}

void doswap(Fraction** fp1, Fraction** fp2)
{
	Fraction* tmp = *fp1;
	*fp1 = *fp2;
	*fp2 = tmp;
}

void sort(Fraction* fpa[], int size)
{
	bool swap;
	do
	{
		swap = false;
		for (int i = 0; i < size - 1; i++)
		{
			if (fpa[i]->num * fpa[i + 1]->den > fpa[i + 1]->num * fpa[i]->den)
			{
				doswap(&fpa[i], &fpa[i + 1]);
				swap = true;
			}
		}
	} while (swap);
	cout << endl;
	for (int j = 0; j < size; j++)
	{
		cout << fpa[j]->num << "/" << fpa[j]->den << endl;
	}
	cout << endl;
}

int search_(const Fraction& search, Fraction* fracptrs[], int size)
{
	int first = 0, last = size - 1, mid = (first + last) / 2;

	while (first <= last)
	{
		if ((search.num * fracptrs[mid]->den) < (search.den * fracptrs[mid]->num)) 
		{
			last = mid - 1;
			mid = (first + last) / 2;
		}
		else if ((search.num * fracptrs[mid]->den) > (search.den * fracptrs[mid]->num))
		{
			first = mid + 1;
			mid = (first + last) / 2;
		}
		else
		{
			return mid;
		}
	}
	return -1;
}

void read_(fstream& fracFile, int index, Fraction* fracptrs[])
{
	
	if (!fracFile)
		cout << "\nFile does not exist.." << endl << endl;
	else
	{
		cout << endl;
		fracFile.seekg((sizeof(Fraction*) * index), ios::beg);
		fracFile.read((char *)&fracptrs[index], sizeof(fracptrs[index]));
		while (!fracFile.eof())
		{
			cout << fracptrs[index]->num << '/' << fracptrs[index]->den;
			fracFile.read((char *)&fracptrs[index], sizeof(fracptrs[index]));
		}
		cout << endl << endl;
	}
}

void reduce(int& num, int& den)
{
	for (int i = num * den; i > 1; i--)
	{
		if (num % i == 0 && den % i == 0)
		{
			num /= i;
			den /= i;
		}
	}
}

void sum(Fraction* fracptrs[], int size)
{
	int sum_num = 0, sum_den = 0;
	for (int i = 0; i < size - 1; i++)
	{
		sum_num += (fracptrs[i]->num * fracptrs[i + 1]->den) + (fracptrs[i + 1]->num * fracptrs[i]->den);
		sum_den += fracptrs[i]->den * fracptrs[i + 1]->den;
		reduce(sum_num, sum_den);
	}
	
	cout << "\nSum of fractions: " << sum_num << "/" << sum_den << endl << endl;
}

void save(fstream& fracsfile, Fraction fracs[], int size)
{
	if (!fracsfile)
		cout << "\nFile does not exist." << endl << endl;
	else
	{
		for (int i = 0; i < size; i++)
		{
			fracsfile.write((char *)&fracs[i], sizeof(fracs[i]));
		}
		cout << "\nFractions saved to file." << endl << endl;
	}
}

void delete_all(Fraction* fracptrs[], int size)
{
	for (int i = 0; i < size; i++)
		delete fracptrs[i];
	fracptrs = { 0 };
	size = 0;
}