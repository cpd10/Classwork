//Darius Hooks
#include <iostream>
#include "toll.h"
#include <conio.h>
#include <iomanip>
using namespace std;
void inputCourseData(TollBooth*, int);
void outputCourseInfo(TollBooth*, float&);
void displayAvgToll(float);
int main()

{
	int maxCourses;
	float totalTollAmt = 0;
	cout << "How many courses maximum? ";
	cin >> maxCourses;
	cout << endl;
	TollBooth* tboothPtr;
	tboothPtr = new TollBooth[maxCourses];

	inputCourseData(tboothPtr, maxCourses);
	outputCourseInfo(tboothPtr, totalTollAmt);
	displayAvgToll(totalTollAmt);

	delete[] tboothPtr;
	
	cout << "\nPress any key to continue....";
	_getch();
	return 0;

}

void inputCourseData(TollBooth* tboothPtr, int maxCourses)
{
	char answer;
	for (int j = 0; j < maxCourses; j++)
		cout << "Now Creating an uninitialized course element....\n";
	for (int i = 0; i < maxCourses; i++)
	{
		cout << "\nEnter 'y' to initialize new course data(enter any other character to quit): ";
		cin >> answer;
		if (answer == 'y' || answer == 'Y')
		{
			cout << "\nFor Course " << i + 1 << ":";
			tboothPtr[i].setStudents();
		}
		else
			break;
	}
}

void outputCourseInfo(TollBooth* tboothptr, float& toll)
{
	int count = TollBooth::getCourseCount();
	for (int i = 0; i < count; i++)
	{
		cout << "\nFor Course " << i + 1 << ":";
		tboothptr[i].getStudents(toll);
	}
}

void displayAvgToll(float toll)
{
	if (toll == 0)
		cout << "\nNo actual courses\n";
	else
		cout << "\nThe average toll per course is $ " 
		<< fixed << setprecision(2) << toll / TollBooth::getCourseCount() << endl;
}